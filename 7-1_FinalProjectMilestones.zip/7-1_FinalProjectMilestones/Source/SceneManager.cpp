// SceneManager.cpp
#include "SceneManager.h"
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>
#include <vector>
#include <cmath>

// Constructor
SceneManager::SceneManager() {}

// Destructor
SceneManager::~SceneManager() {}

// CreateCylinder Method
void SceneManager::CreateCylinder()
{
    const float radius = 0.5f;
    const float height = 2.0f;
    const int segments = 36;

    std::vector<float> vertices;
    std::vector<unsigned int> indices;

    // Top and bottom circle vertices
    for (int i = 0; i <= segments; i++) {
        float angle = i * 2.0f * glm::pi<float>() / segments;
        float x = radius * cos(angle);
        float z = radius * sin(angle);

        // Top circle
        vertices.push_back(x); vertices.push_back(height / 2); vertices.push_back(z);
        vertices.push_back(x / radius + 0.5f); vertices.push_back(z / radius + 0.5f); // Texture coords

        // Bottom circle
        vertices.push_back(x); vertices.push_back(-height / 2); vertices.push_back(z);
        vertices.push_back(x / radius + 0.5f); vertices.push_back(z / radius + 0.5f); // Texture coords
    }

    // Indices for the cylinder sides
    for (int i = 0; i < segments; i++) {
        int top1 = i * 2;
        int bottom1 = top1 + 1;
        int top2 = (top1 + 2) % (2 * segments);
        int bottom2 = (bottom1 + 2) % (2 * segments);

        // Side faces
        indices.push_back(top1); indices.push_back(bottom1); indices.push_back(top2);
        indices.push_back(bottom1); indices.push_back(bottom2); indices.push_back(top2);
    }

    glGenVertexArrays(1, &m_cylinderVAO);
    GLuint VBO, EBO;
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(m_cylinderVAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

// RenderCylinder Method
void SceneManager::RenderCylinder()
{
    glBindVertexArray(m_cylinderVAO);
    glBindTexture(GL_TEXTURE_2D, m_cylinderTexture);
    glDrawElements(GL_TRIANGLES, 36 * 6, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

// PrepareScene Method
void SceneManager::PrepareScene()
{
    // Load textures
    m_planeTexture = LoadTexture("../../Textures/grass_texture.jpg");
    m_cubeTexture = LoadTexture("../../Textures/stone_texture.jpg");
    m_cylinderTexture = LoadTexture("../../Textures/metal_texture.jpg");

    // Create shapes
    CreatePlane();
    CreateCube();
    CreateCylinder();
}

// RenderScene Method
void SceneManager::RenderScene()
{
    RenderPlane();
    RenderCube();
    RenderCylinder();
}
