#ifndef SCENEMANAGER_H
#define SCENEMANAGER_H

#include <GL/glew.h>
#include <glm/glm.hpp>
#include "ShaderManager.h"
#include "ShapeMeshes.h"

class SceneManager
{
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    void PrepareScene();
    void RenderScene();
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);
    void SetShaderColor(float red, float green, float blue, float alpha);

    // New methods for creating and rendering shapes
    void CreateCube();
    void CreateSphere();
    void RenderShape();

private:
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_basicMeshes;

    GLuint m_cubeVAO;
    GLuint m_sphereVAO;
};

#endif
