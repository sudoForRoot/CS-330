#ifndef VIEWMANAGER_H
#define VIEWMANAGER_H

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <GLFW/glfw3.h>

class ViewManager
{
public:
    ViewManager();
    ~ViewManager();
    void HandleInput(GLFWwindow* window);
    void PrepareSceneView();
    void ToggleProjection();

private:
    glm::vec3 m_cameraPos;
    glm::vec3 m_cameraFront;
    glm::vec3 m_cameraUp;
    float m_speed;
    float m_yaw;
    float m_pitch;
    bool m_isPerspective;

    glm::mat4 m_view;
    glm::mat4 m_projection;

    void UpdateViewMatrix();
    void UpdateProjectionMatrix();
};

#endif // VIEWMANAGER_H
