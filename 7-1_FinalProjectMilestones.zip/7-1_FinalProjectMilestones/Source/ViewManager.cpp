#include "ViewManager.h"
#include <iostream>

ViewManager::ViewManager()
    : m_cameraPos(0.0f, 0.0f, 3.0f), m_cameraFront(0.0f, 0.0f, -1.0f), m_cameraUp(0.0f, 1.0f, 0.0f),
      m_speed(0.05f), m_yaw(-90.0f), m_pitch(0.0f), m_isPerspective(true)
{
    UpdateViewMatrix();
    UpdateProjectionMatrix();
}

ViewManager::~ViewManager() {}

void ViewManager::HandleInput(GLFWwindow* window)
{
    float deltaSpeed = glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS ? 0.1f : 0.05f;

    // Camera movement controls
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) m_cameraPos += deltaSpeed * m_cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) m_cameraPos -= deltaSpeed * m_cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) m_cameraPos -= glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * deltaSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) m_cameraPos += glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * deltaSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) m_cameraPos.y += deltaSpeed;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) m_cameraPos.y -= deltaSpeed;

    // Camera projection mode toggle
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) m_isPerspective = true;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) m_isPerspective = false;

    UpdateViewMatrix();
    UpdateProjectionMatrix();
}

void ViewManager::PrepareSceneView(GLuint programID)
{
    GLint viewLoc = glGetUniformLocation(programID, "view");
    GLint projLoc = glGetUniformLocation(programID, "projection");
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(m_view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(m_projection));
}

void ViewManager::UpdateViewMatrix()
{
    m_view = glm::lookAt(m_cameraPos, m_cameraPos + m_cameraFront, m_cameraUp);
}

void ViewManager::UpdateProjectionMatrix()
{
    if (m_isPerspective)
    {
        m_projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);
    }
    else
    {
        m_projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
    }
}
